###################################################
###################################################
###                                             ###
###      By Saif Adnan - iraqipro@gmail.com     ###
###                                             ### 
###################################################
###################################################

In images folder therer is 2 images: 
1-sprite.png (sprite saved as PNG-8 (256 colors) Interlaced.)
2-sprite-old.png (saved as PNG-24 Interlaced.)